# Play Store listing (draft)

Title: Battery Tracker: Charge History
Short description (80 chars max): Track every charge and drain with date, time, duration, and % gained.

Full description:
Battery Tracker automatically records every time you charge your phone and every stretch on battery.
- See when you plugged in and unplugged, how long it charged, and how many percent it gained
- Live battery ring with temperature, voltage, current, health, and time estimates
- Charge limit, low battery, and overheat alerts
- Full history grouped by day, with time at 100% and screen-on versus screen-off drain
- Charts, charger comparison, battery health estimate, and charging tips
- Battery details tab: health, cycles, voltage, current, power, counters, and system estimates
- Optional battery use by app: screen time and estimated battery share per app
- Export your history as a CSV file
- Optional fingerprint, face, or PIN app lock
- 100% private: your data never leaves your phone, and the app has no internet access

Category: Tools
Data safety form: no data collected, no data shared.
Foreground service declaration: special use - records battery charging and discharging sessions.

Play Console note: the app declares PACKAGE_USAGE_STATS (optional feature). Check Play's current policy and disclosure requirements for it before publishing, and describe it in the data safety form.
