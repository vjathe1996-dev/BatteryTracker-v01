# Play Store listing (draft)

Title: Battery Tracker: Charge History
Short description (80 chars max): Track every charge and drain with date, time, duration, and % gained.

Full description:
Battery Tracker automatically records every time you charge your phone and every stretch on battery.
- See when you plugged in and unplugged, how long it charged, and how many percent it gained
- Live battery ring, average charge speed, and average drain speed
- Full charging history grouped by day
- Optional fingerprint, face, or PIN app lock
- 100% private: your data never leaves your phone, and the app has no internet access

Category: Tools
Data safety form: no data collected, no data shared.
Foreground service declaration: special use - records battery charging and discharging sessions.
