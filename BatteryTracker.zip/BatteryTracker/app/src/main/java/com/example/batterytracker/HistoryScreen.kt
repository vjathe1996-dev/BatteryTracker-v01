package com.example.batterytracker

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

@Composable
fun HistoryScreen(settings: AppSettings) {
    val ctx = LocalContext.current
    val dao = remember { AppDb.get(ctx).dao() }
    val flow = remember { dao.all() }
    val sessions by flow.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var filter by rememberSaveable { mutableStateOf(1) }
    val shown = when (filter) {
        1 -> sessions.filter { it.charging }
        2 -> sessions.filter { !it.charging }
        else -> sessions
    }
    val groups = remember(shown) { shown.groupBy { dayLabel(it.startTime) } }
    val totalMs = shown.sumOf { it.durationMs }
    val totalPct = shown.sumOf { abs(it.gain) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("History", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        item { FilterRow(listOf("All", "Charging", "On battery"), filter) { filter = it } }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatBox("${shown.size}", "Sessions", MaterialTheme.colorScheme.onSurface, Modifier.weight(1f))
                StatBox(formatDuration(totalMs), "Total time", MaterialTheme.colorScheme.onSurface, Modifier.weight(1f))
                StatBox(
                    "$totalPct%",
                    when (filter) { 1 -> "Charged"; 2 -> "Drained"; else -> "Total change" },
                    if (filter == 2) Orange else Green, Modifier.weight(1f)
                )
            }
        }
        item {
            Text(
                "Tap a session for details. Swipe left to delete.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (shown.isEmpty()) item { Text("No sessions here yet.") }
        for ((day, list) in groups) {
            item(key = "h$day") {
                Text(day, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(list, key = { it.id }) { s ->
                SwipeDelete(enabled = !s.open, onDelete = { scope.launch(Dispatchers.IO) { dao.delete(s) } }) {
                    SessionCard(s, settings)
                }
            }
        }
    }
}

@Composable
fun SwipeDelete(enabled: Boolean, onDelete: () -> Unit, content: @Composable () -> Unit) {
    val state = rememberSwipeToDismissBoxState(confirmValueChange = { v ->
        if (v == SwipeToDismissBoxValue.EndToStart) {
            onDelete()
            true
        } else false
    })
    SwipeToDismissBox(
        state = state,
        enableDismissFromStartToEnd = false,
        enableDismissFromEndToStart = enabled,
        backgroundContent = {
            val bg = if (state.dismissDirection == SwipeToDismissBoxValue.EndToStart) Red else Color.Transparent
            Box(Modifier.fillMaxSize().background(bg), contentAlignment = Alignment.CenterEnd) {
                Text("Delete", color = Color.White, modifier = Modifier.padding(end = 20.dp))
            }
        },
        content = { content() }
    )
}

@Composable
fun SessionCard(s: Session, settings: AppSettings) {
    var expanded by remember { mutableStateOf(false) }
    val accent = if (s.charging) Green else Orange
    val fmt = SimpleDateFormat("h:mm a", Locale.getDefault())
    val full = SimpleDateFormat("EEE, d MMM · h:mm a", Locale.getDefault())

    Card(Modifier.fillMaxWidth().animateContentSize().clickable { expanded = !expanded }) {
        Row(Modifier.height(IntrinsicSize.Min)) {
            Box(Modifier.width(6.dp).fillMaxHeight().background(accent))
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            (if (s.charging) "Charging · ${s.source}" else "On battery") + if (s.open) " · live" else "",
                            fontWeight = FontWeight.Bold, color = accent
                        )
                        Text(
                            "${fmt.format(Date(s.startTime))} → ${if (s.open) "now" else fmt.format(Date(s.endTime))}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(signed(s.gain), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                }
                LinearProgressIndicator(progress = { s.endPct / 100f }, modifier = Modifier.fillMaxWidth(), color = accent)
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("${s.startPct}% → ${s.endPct}%", style = MaterialTheme.typography.bodySmall)
                    Text("⏱ ${formatDuration(s.durationMs)}", style = MaterialTheme.typography.bodySmall)
                    Text("%.1f %%/h".format(s.rate()), style = MaterialTheme.typography.bodySmall)
                }
                if (expanded) {
                    HorizontalDivider()
                    Detail("Started", full.format(Date(s.startTime)))
                    Detail("Ended", if (s.open) "In progress" else full.format(Date(s.endTime)))
                    Detail("Max temperature", fmtTemp(s.maxTempC, settings.useF))
                    if (s.charging) Detail("Time at 100%", formatDuration(s.fullMs))
                    if (s.screenOnMs > 0) {
                        Detail("Screen on", "${formatDuration(s.screenOnMs)} · ${signed(s.screenOnPct)}")
                    }
                    if (s.screenOffMs > 0) {
                        Detail("Screen off", "${formatDuration(s.screenOffMs)} · ${signed(s.screenOffPct)}")
                    }
                    s.capacityMah()?.let { Detail("Estimated capacity", "%.0f mAh".format(it)) }
                }
            }
        }
    }
}

@Composable
fun Detail(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
    }
}
