package com.example.batterytracker

import android.content.Context
import android.content.Intent
import android.os.PowerManager
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class PulseWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        try {
            val pm = applicationContext.getSystemService(Context.POWER_SERVICE) as PowerManager
            Tracker.pulse(applicationContext, pm.isInteractive)
            if (!BatteryService.running) {
                ContextCompat.startForegroundService(
                    applicationContext, Intent(applicationContext, BatteryService::class.java)
                )
            }
        } catch (e: Exception) {
        }
        return Result.success()
    }
}
