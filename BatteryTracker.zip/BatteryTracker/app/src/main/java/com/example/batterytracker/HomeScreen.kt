package com.example.batterytracker

import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HomeScreen(settings: AppSettings, listState: LazyListState) {
    val ctx = LocalContext.current
    val dao = remember { AppDb.get(ctx).dao() }
    val flow = remember { dao.all() }
    val sampleFlow = remember { dao.chargeSamples() }
    val sessions by flow.collectAsState(initial = emptyList())
    val chargeSamples by sampleFlow.collectAsState(initial = emptyList())
    val live by rememberLive()
    val check by rememberHealthCheck()
    val rates = remember(chargeSamples) { bandRates(chargeSamples) }
    val done = sessions.filter { !it.open }
    val chargeRate = avgRate(done.filter { it.charging }.take(10))
    val drainRate = avgRate(done.filter { !it.charging }.take(10))
    val current = sessions.firstOrNull { it.open }
    val color = if (live.charging) Green else Orange
    val estimate = when {
        live.charging && live.pct >= 100 -> "Full"
        live.charging && live.systemToFullMs > 0 -> "~" + formatDuration(live.systemToFullMs)
        live.charging -> etaToFullHours(live.pct, rates, chargeRate)?.let { "~" + formatHours(it) } ?: "–"
        live.systemLeftMs > 0 -> "~" + formatDuration(live.systemLeftMs)
        drainRate > 0 -> "~" + formatHours(live.pct / drainRate)
        else -> "–"
    }
    val timeFmt = SimpleDateFormat("h:mm a", Locale.getDefault())

    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("Battery Tracker", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        if (!check.notificationsOn) {
            item {
                WarnCard("Notifications are off", "Charge limit, low battery, and overheat alerts can't reach you.", "Open notification settings") {
                    openNotificationSettings(ctx)
                }
            }
        }
        if (!check.unrestricted) {
            item {
                WarnCard("Android may stop the tracker", "Allow background use so no charges are missed.", "Open battery settings") {
                    openSafely(ctx, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    BatteryRing(live.pct, color)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            if (live.charging) "⚡ Charging (${live.source})" else "🔋 On battery",
                            style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = color
                        )
                        if (current != null) {
                            Text("Since ${timeFmt.format(Date(current.startTime))} · ${formatDuration(current.durationMs)}")
                            Text(
                                "Started at ${current.startPct}%",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Tile("Temperature", fmtTemp(live.tempC, settings.useF), "Battery temperature. Above 40°C is hot.", Modifier.weight(1f))
                Tile("Voltage", "%.2f V".format(live.voltageMv / 1000f), "Battery voltage right now.", Modifier.weight(1f))
                Tile("Current", if (live.currentMa > 0) "${live.currentMa} mA" else "n/a", "Charge or drain current. Not available on every phone.", Modifier.weight(1f))
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Tile("Health", live.health, "Health status reported by Android.", Modifier.weight(1f))
                Tile("Cycles", if (live.cycles >= 0) "${live.cycles}" else "n/a", "Charge cycle count. Needs Android 14 or newer and phone support.", Modifier.weight(1f))
                Tile(
                    if (live.charging) "To full" else "Time left", estimate,
                    "Uses Android's own estimate when available, otherwise your charging history, including the slowdown near full.",
                    Modifier.weight(1f)
                )
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatBox("%.1f %%/h".format(chargeRate), "Avg charge", Green, Modifier.weight(1f))
                StatBox("%.1f %%/h".format(drainRate), "Avg drain", Orange, Modifier.weight(1f))
                StatBox("${done.size}", "Sessions", MaterialTheme.colorScheme.onSurface, Modifier.weight(1f))
            }
        }
        item { Text("Recent sessions", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        if (sessions.isEmpty()) {
            item { Text("No sessions yet. Plug in or unplug your phone and wait a couple of minutes.") }
        }
        items(sessions.take(3), key = { it.id }) { SessionCard(it, settings) }
    }
}

@Composable
fun BatteryRing(pct: Int, color: Color) {
    val p by animateFloatAsState(targetValue = pct / 100f, animationSpec = tween(900), label = "ring")
    val track = MaterialTheme.colorScheme.surfaceVariant
    Box(
        Modifier.size(110.dp).semantics { contentDescription = "Battery at $pct percent" },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
            val inset = 6.dp.toPx()
            val sz = Size(size.width - inset * 2, size.height - inset * 2)
            drawArc(track, -90f, 360f, false, Offset(inset, inset), sz, style = stroke)
            drawArc(color, -90f, 360f * p, false, Offset(inset, inset), sz, style = stroke)
        }
        Text("$pct%", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Tile(label: String, value: String, hint: String, modifier: Modifier) {
    var open by remember { mutableStateOf(false) }
    Card(modifier) {
        Column(
            Modifier.clickable { open = !open }.animateContentSize().padding(10.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text(label, style = MaterialTheme.typography.labelSmall)
            if (open) {
                Spacer(Modifier.height(4.dp))
                Text(
                    hint, style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center
                )
            }
        }
    }
}
