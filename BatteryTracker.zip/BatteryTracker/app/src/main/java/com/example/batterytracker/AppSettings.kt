package com.example.batterytracker

import android.content.SharedPreferences
import androidx.compose.runtime.*

class AppSettings(private val sp: SharedPreferences) {
    var lockOn by mutableStateOf(sp.getBoolean("lock", false))
    var secureOn by mutableStateOf(sp.getBoolean("secure", true))
    var limitOn by mutableStateOf(sp.getBoolean("limitOn", true))
    var limitPct by mutableIntStateOf(sp.getInt("limitPct", 100))
    var lowOn by mutableStateOf(sp.getBoolean("lowOn", true))
    var lowPct by mutableIntStateOf(sp.getInt("lowPct", 15))
    var heatOn by mutableStateOf(sp.getBoolean("heatOn", true))
    var heatC by mutableIntStateOf(sp.getInt("heatC", 40))
    var useF by mutableStateOf(sp.getBoolean("useF", false))
    var designMah by mutableIntStateOf(sp.getInt("designMah", 0))
    var theme by mutableIntStateOf(sp.getInt("theme", 0))
    var onboarded by mutableStateOf(sp.getBoolean("onboarded", false))
    var keepDays by mutableIntStateOf(sp.getInt("keepDays", 0))
    var lockGraceSec by mutableIntStateOf(sp.getInt("lockGraceSec", 30))

    fun save() {
        sp.edit()
            .putBoolean("lock", lockOn).putBoolean("secure", secureOn)
            .putBoolean("limitOn", limitOn).putInt("limitPct", limitPct)
            .putBoolean("lowOn", lowOn).putInt("lowPct", lowPct)
            .putBoolean("heatOn", heatOn).putInt("heatC", heatC)
            .putBoolean("useF", useF).putInt("designMah", designMah)
            .putInt("theme", theme)
            .putBoolean("onboarded", onboarded).putInt("keepDays", keepDays).putInt("lockGraceSec", lockGraceSec)
            .apply()
    }
}
