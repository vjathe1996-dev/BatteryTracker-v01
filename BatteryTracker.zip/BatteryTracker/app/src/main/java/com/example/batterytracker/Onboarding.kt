package com.example.batterytracker

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun OnboardingScreen(onNotifications: () -> Unit, onBattery: () -> Unit, onUsage: () -> Unit, onDone: () -> Unit) {
    Column(
        Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Welcome to Battery Tracker", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Two quick steps help the tracker run reliably, and one more is optional. Everything stays on your phone.")
        StepCard(
            "1. Allow notifications",
            "Needed for your charge limit, low battery, and overheat alerts.",
            "Allow notifications", onNotifications
        )
        StepCard(
            "2. Allow background use",
            "In the list, find Battery Tracker and choose Don't optimize or Unrestricted. On Xiaomi, Samsung, OnePlus, and similar phones, also set the app to No restrictions or Never sleeping in the phone's own battery settings.",
            "Open battery settings", onBattery
        )
        StepCard(
            "3. Optional: battery use by app",
            "Turn on Usage access to see which apps were on screen the most and an estimate of their battery use. Skip it if you prefer.",
            "Open usage access", onUsage
        )
        Button(onClick = onDone, modifier = Modifier.fillMaxWidth()) { Text("Start tracking") }
        Text(
            "You can check these again any time on the Home and Details tabs.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun StepCard(title: String, text: String, button: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(text, style = MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) { Text(button) }
        }
    }
}
