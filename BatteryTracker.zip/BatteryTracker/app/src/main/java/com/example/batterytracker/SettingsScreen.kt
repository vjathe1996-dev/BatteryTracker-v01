package com.example.batterytracker

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(
    settings: AppSettings,
    onLock: (Boolean) -> Boolean,
    onSecure: (Boolean) -> Unit,
    scroll: ScrollState
) {
    val ctx = LocalContext.current
    val dao = remember { AppDb.get(ctx).dao() }
    val scope = rememberCoroutineScope()
    var lock by remember { mutableStateOf(settings.lockOn) }
    var secure by remember { mutableStateOf(settings.secureOn) }
    var cap by remember { mutableStateOf(if (settings.designMah > 0) settings.designMah.toString() else "") }
    var confirmClear by remember { mutableStateOf(false) }
    val version = remember { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }
    val graceOptions = listOf(0, 30, 120)
    val keepOptions = listOf(0, 365, 180, 90)

    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                val all = dao.snapshot()
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(toCsv(all).toByteArray()) }
                withContext(Dispatchers.Main) {
                    Toast.makeText(ctx, "Exported ${all.size} sessions", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                val n = try {
                    importCsv(ctx, uri, dao)
                } catch (e: Exception) {
                    -1
                }
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        ctx, if (n >= 0) "Imported $n sessions" else "Couldn't read that file",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().imePadding().verticalScroll(scroll).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        Section("Security") {
            SettingRow("App lock", "Ask for fingerprint, face, or phone PIN when opening the app.", lock) {
                lock = onLock(it) && it
            }
            if (lock) {
                Text("Lock after leaving the app")
                FilterRow(
                    listOf("Immediately", "30 seconds", "2 minutes"),
                    graceOptions.indexOf(settings.lockGraceSec).coerceAtLeast(0)
                ) {
                    settings.lockGraceSec = graceOptions[it]
                    settings.save()
                }
            }
            SettingRow("Hide screen in recent apps", "Blocks screenshots and blanks the app preview.", secure) {
                secure = it
                onSecure(it)
            }
        }

        Section("Alerts") {
            SettingRow("Charge limit alert", "Notify when charging reaches the limit.", settings.limitOn) {
                settings.limitOn = it; settings.save()
            }
            if (settings.limitOn) {
                Text("Alert at ${settings.limitPct}%")
                Slider(
                    value = settings.limitPct.toFloat(),
                    onValueChange = { settings.limitPct = it.roundToInt() },
                    onValueChangeFinished = { settings.save() },
                    valueRange = 50f..100f
                )
            }
            SettingRow("Low battery alert", "Notify when the battery runs low.", settings.lowOn) {
                settings.lowOn = it; settings.save()
            }
            if (settings.lowOn) {
                Text("Alert at ${settings.lowPct}%")
                Slider(
                    value = settings.lowPct.toFloat(),
                    onValueChange = { settings.lowPct = it.roundToInt() },
                    onValueChangeFinished = { settings.save() },
                    valueRange = 5f..50f
                )
            }
            SettingRow("Overheat alert", "Notify when the battery gets hot.", settings.heatOn) {
                settings.heatOn = it; settings.save()
            }
            if (settings.heatOn) {
                Text("Alert at ${fmtTemp(settings.heatC.toFloat(), settings.useF)}")
                Slider(
                    value = settings.heatC.toFloat(),
                    onValueChange = { settings.heatC = it.roundToInt() },
                    onValueChangeFinished = { settings.save() },
                    valueRange = 35f..50f
                )
            }
        }

        Section("Display") {
            Text("Temperature unit")
            FilterRow(listOf("°C", "°F"), if (settings.useF) 1 else 0) { settings.useF = it == 1; settings.save() }
            Text("Theme")
            FilterRow(listOf("System", "Light", "Dark"), settings.theme) { settings.theme = it; settings.save() }
        }

        Section("Battery") {
            OutlinedTextField(
                value = cap,
                onValueChange = { v ->
                    cap = v.filter { it.isDigit() }.take(5)
                    settings.designMah = cap.toIntOrNull() ?: 0
                    settings.save()
                },
                label = { Text("Original capacity in mAh (optional)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "Used to show a health percentage in Insights.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Section("Data") {
            Text("Keep history for")
            FilterRow(
                listOf("Forever", "1 year", "6 months", "3 months"),
                keepOptions.indexOf(settings.keepDays).coerceAtLeast(0)
            ) {
                settings.keepDays = keepOptions[it]
                settings.save()
            }
            Button(onClick = { exporter.launch("battery_history.csv") }, modifier = Modifier.fillMaxWidth()) {
                Text("Export history (CSV)")
            }
            OutlinedButton(onClick = { importer.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) {
                Text("Import history (CSV)")
            }
            OutlinedButton(onClick = { confirmClear = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Clear all history")
            }
        }

        Text(
            "All your battery data stays on this phone. The app has no internet access.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text("Version $version", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear all history?") },
            text = { Text("This deletes every recorded session. It can't be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmClear = false
                    scope.launch(Dispatchers.IO) {
                        dao.clearSamples()
                        dao.clearAll()
                    }
                }) { Text("Clear") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } }
        )
    }
}

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall, color = Green, fontWeight = FontWeight.Bold)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
        }
    }
}

@Composable
fun SettingRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
