package com.example.batterytracker

import android.text.format.DateUtils
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

val Green = Color(0xFF2E9E5B)
val Orange = Color(0xFFF29D38)
val Red = Color(0xFFD9534F)

val Session.durationMs: Long get() = endTime - startTime
val Session.gain: Int get() = endPct - startPct

fun Session.rate(): Double {
    val h = durationMs / 3_600_000.0
    return if (h > 0) abs(gain / h) else 0.0
}

fun Session.capacityMah(): Double? {
    val dp = endPct - startPct
    val dc = endCounterUah - startCounterUah
    if (!charging || open || dp < 20 || startCounterUah <= 0 || dc <= 0) return null
    val mah = dc / 1000.0 / dp * 100.0
    return if (mah in 800.0..20000.0) mah else null
}

fun avgRate(l: List<Session>): Double {
    val r = l.filter { it.durationMs > 0 && it.gain != 0 }.map { it.rate() }
    return if (r.isEmpty()) 0.0 else r.average()
}

fun formatDuration(ms: Long): String {
    val m = ms / 60_000
    return if (m >= 60) "${m / 60}h ${m % 60}m" else "${m}m"
}

fun formatHours(h: Double): String = formatDuration((h * 3_600_000).toLong())

fun fmtTemp(c: Float, useF: Boolean): String =
    if (useF) "%.0f°F".format(c * 9 / 5 + 32) else "%.0f°C".format(c)

fun signed(n: Int): String = if (n > 0) "+$n%" else "$n%"

fun dayLabel(ms: Long): String = when {
    DateUtils.isToday(ms) -> "Today"
    DateUtils.isToday(ms + 86_400_000L) -> "Yesterday"
    else -> SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date(ms))
}

fun toCsv(list: List<Session>): String {
    val f = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
    val sb = StringBuilder("type,start,end,duration_min,start_pct,end_pct,change_pct,source,max_temp_c,time_at_100_min,screen_on_min,screen_off_min\n")
    for (s in list.sortedBy { it.startTime }) {
        sb.append(if (s.charging) "charge" else "drain").append(',')
            .append(f.format(Date(s.startTime))).append(',')
            .append(f.format(Date(s.endTime))).append(',')
            .append(s.durationMs / 60_000).append(',')
            .append(s.startPct).append(',').append(s.endPct).append(',').append(s.gain).append(',')
            .append(s.source).append(',')
            .append("%.1f".format(Locale.US, s.maxTempC)).append(',')
            .append(s.fullMs / 60_000).append(',')
            .append(s.screenOnMs / 60_000).append(',')
            .append(s.screenOffMs / 60_000).append('\n')
    }
    return sb.toString()
}

@Composable
fun StatBox(value: String, label: String, color: Color, modifier: Modifier) {
    Card(modifier) {
        Column(Modifier.padding(12.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = color)
            Text(label, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
fun FilterRow(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, label ->
            FilterChip(selected = selected == i, onClick = { onSelect(i) }, label = { Text(label) })
        }
    }
}
