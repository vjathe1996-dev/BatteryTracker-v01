package com.example.batterytracker

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.delay

data class Live(
    val pct: Int = 0,
    val charging: Boolean = false,
    val source: String = "",
    val tempC: Float = 0f,
    val voltageMv: Int = 0,
    val currentMa: Int = 0,
    val health: String = "Unknown",
    val cycles: Int = -1,
    val systemToFullMs: Long = -1L,
    val systemLeftMs: Long = -1L
)

data class Check(val notificationsOn: Boolean = true, val unrestricted: Boolean = true)

fun readLive(ctx: Context): Live {
    val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return Live()
    val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
    val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
    val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
    val plug = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
    val ma = normMa(safe { bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) } ?: Int.MIN_VALUE)
    val health = when (i.getIntExtra(BatteryManager.EXTRA_HEALTH, 0)) {
        BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
        BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheated"
        BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
        BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over voltage"
        BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
        BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Failure"
        else -> "Unknown"
    }
    val cycles = if (Build.VERSION.SDK_INT >= 34) i.getIntExtra(BatteryManager.EXTRA_CYCLE_COUNT, -1) else -1
    val toFull: Long = if (plug != 0 && Build.VERSION.SDK_INT >= 28) {
        safe { bm.computeChargeTimeRemaining() } ?: -1L
    } else -1L
    val left: Long = if (plug == 0 && Build.VERSION.SDK_INT >= 33) {
        safe { pm.batteryDischargePrediction?.toMillis() } ?: -1L
    } else -1L
    return Live(
        pct = level * 100 / scale,
        charging = plug != 0,
        source = when (plug) {
            BatteryManager.BATTERY_PLUGGED_AC -> "AC"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
            0 -> ""
            else -> "Other"
        },
        tempC = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f,
        voltageMv = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0),
        currentMa = ma,
        health = health,
        cycles = cycles,
        systemToFullMs = toFull,
        systemLeftMs = left
    )
}

@Composable
fun rememberLive(): State<Live> {
    val ctx = LocalContext.current
    return produceState(initialValue = Live()) {
        while (true) {
            value = readLive(ctx)
            delay(2000)
        }
    }
}

@Composable
fun rememberHealthCheck(): State<Check> {
    val ctx = LocalContext.current
    return produceState(initialValue = Check()) {
        while (true) {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            value = Check(
                NotificationManagerCompat.from(ctx).areNotificationsEnabled(),
                safe { pm.isIgnoringBatteryOptimizations(ctx.packageName) } ?: true
            )
            delay(3000)
        }
    }
}
