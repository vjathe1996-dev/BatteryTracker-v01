package com.example.batterytracker

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import kotlin.math.abs

data class Live(
    val pct: Int = 0,
    val charging: Boolean = false,
    val source: String = "",
    val tempC: Float = 0f,
    val voltageMv: Int = 0,
    val currentMa: Int = 0,
    val health: String = "Unknown",
    val cycles: Int = -1
)

fun readLive(ctx: Context): Live {
    val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return Live()
    val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
    val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
    val plug = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
    val raw = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
    val ma = if (raw == Int.MIN_VALUE) 0 else {
        val a = abs(raw)
        if (a >= 10_000) a / 1000 else a
    }
    val health = when (i.getIntExtra(BatteryManager.EXTRA_HEALTH, 0)) {
        BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
        BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheated"
        BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
        BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over voltage"
        BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
        BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Failure"
        else -> "Unknown"
    }
    val cycles = if (Build.VERSION.SDK_INT >= 34) i.getIntExtra(BatteryManager.EXTRA_CYCLE_COUNT, -1) else -1
    return Live(
        pct = level * 100 / scale,
        charging = plug != 0,
        source = when (plug) {
            BatteryManager.BATTERY_PLUGGED_AC -> "AC"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
            else -> ""
        },
        tempC = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f,
        voltageMv = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0),
        currentMa = ma,
        health = health,
        cycles = cycles
    )
}

@Composable
fun rememberLive(): State<Live> {
    val ctx = LocalContext.current
    return produceState(initialValue = Live()) {
        while (true) {
            value = readLive(ctx)
            delay(2000)
        }
    }
}
