package com.example.batterytracker

import android.content.Context
import android.net.Uri
import java.text.SimpleDateFormat
import java.util.Locale

suspend fun importCsv(ctx: Context, uri: Uri, dao: SessionDao): Int {
    val lines = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readLines() } ?: return 0
    val f = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
    val existing = dao.snapshot().map { it.startTime }.toHashSet()
    var n = 0
    for (line in lines.drop(1)) {
        val p = line.split(',')
        if (p.size < 12) continue
        try {
            val start = f.parse(p[1])?.time ?: continue
            val end = f.parse(p[2])?.time ?: continue
            if (end < start || start in existing) continue
            dao.insert(
                Session(
                    charging = p[0] == "charge",
                    startTime = start, endTime = end,
                    startPct = p[4].toInt(), endPct = p[5].toInt(),
                    source = p[7], maxTempC = p[8].toFloat(),
                    open = false,
                    fullMs = p[9].toLong() * 60_000,
                    screenOnMs = p[10].toLong() * 60_000,
                    screenOffMs = p[11].toLong() * 60_000
                )
            )
            existing.add(start)
            n++
        } catch (e: Exception) {
            continue
        }
    }
    return n
}
