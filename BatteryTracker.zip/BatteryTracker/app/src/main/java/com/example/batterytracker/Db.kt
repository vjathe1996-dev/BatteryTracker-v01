package com.example.batterytracker

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "sessions")
data class Session(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val charging: Boolean,
    val startTime: Long,
    val endTime: Long,
    val startPct: Int,
    val endPct: Int,
    val source: String,
    val maxTempC: Float,
    val open: Boolean = true
)

@Dao
interface SessionDao {
    @Query("SELECT * FROM sessions ORDER BY startTime DESC")
    fun all(): Flow<List<Session>>

    @Query("SELECT * FROM sessions WHERE open = 1 LIMIT 1")
    suspend fun openSession(): Session?

    @Insert suspend fun insert(s: Session): Long
    @Update suspend fun update(s: Session)
    @Delete suspend fun delete(s: Session)
}

@Database(entities = [Session::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): SessionDao

    companion object {
        @Volatile private var instance: AppDb? = null
        fun get(c: Context): AppDb = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "battery.db")
                .build().also { instance = it }
        }
    }
}
