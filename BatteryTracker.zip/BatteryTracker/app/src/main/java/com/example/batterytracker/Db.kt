package com.example.batterytracker

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "sessions")
data class Session(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val charging: Boolean,
    val startTime: Long,
    val endTime: Long,
    val startPct: Int,
    val endPct: Int,
    val source: String,
    val maxTempC: Float,
    val open: Boolean = true,
    val fullMs: Long = 0,
    val screenOnMs: Long = 0,
    val screenOffMs: Long = 0,
    val screenOnPct: Int = 0,
    val screenOffPct: Int = 0,
    val startCounterUah: Long = 0,
    val endCounterUah: Long = 0
)

@Dao
interface SessionDao {
    @Query("SELECT * FROM sessions ORDER BY startTime DESC")
    fun all(): Flow<List<Session>>

    @Query("SELECT * FROM sessions ORDER BY startTime DESC")
    suspend fun snapshot(): List<Session>

    @Query("SELECT * FROM sessions WHERE open = 1 LIMIT 1")
    suspend fun openSession(): Session?

    @Query("DELETE FROM sessions")
    suspend fun clearAll()

    @Insert suspend fun insert(s: Session): Long
    @Update suspend fun update(s: Session)
    @Delete suspend fun delete(s: Session)
}

private val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE sessions ADD COLUMN fullMs INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE sessions ADD COLUMN screenOnMs INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE sessions ADD COLUMN screenOffMs INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE sessions ADD COLUMN screenOnPct INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE sessions ADD COLUMN screenOffPct INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE sessions ADD COLUMN startCounterUah INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE sessions ADD COLUMN endCounterUah INTEGER NOT NULL DEFAULT 0")
    }
}

@Database(entities = [Session::class], version = 2, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): SessionDao

    companion object {
        @Volatile private var instance: AppDb? = null
        fun get(c: Context): AppDb = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "battery.db")
                .addMigrations(MIGRATION_1_2)
                .build().also { instance = it }
        }
    }
}
