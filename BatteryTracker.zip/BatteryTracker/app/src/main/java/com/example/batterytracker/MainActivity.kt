package com.example.batterytracker

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

private val AUTH = BiometricManager.Authenticators.BIOMETRIC_WEAK or
    BiometricManager.Authenticators.DEVICE_CREDENTIAL

class MainActivity : FragmentActivity() {
    private lateinit var settings: AppSettings
    private var unlocked by mutableStateOf(false)
    private var authenticating = false

    private val permission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { startTracking() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        settings = AppSettings(getSharedPreferences("settings", MODE_PRIVATE))
        applySecure(settings.secureOn)

        if (Build.VERSION.SDK_INT >= 33) permission.launch(Manifest.permission.POST_NOTIFICATIONS)
        else startTracking()

        setContent {
            val dark = when (settings.theme) {
                1 -> false
                2 -> true
                else -> isSystemInDarkTheme()
            }
            AppTheme(dark) {
                Surface(Modifier.fillMaxSize()) {
                    if (!settings.lockOn || unlocked) {
                        AppScreen(settings, { setLock(it) }, { setSecure(it) })
                    } else {
                        LockScreen { authenticate() }
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (settings.lockOn && !unlocked) authenticate()
    }

    override fun onStop() {
        super.onStop()
        if (settings.lockOn && !authenticating) unlocked = false
    }

    private fun authenticate() {
        if (authenticating) return
        if (BiometricManager.from(this).canAuthenticate(AUTH) != BiometricManager.BIOMETRIC_SUCCESS) {
            unlocked = true
            return
        }
        authenticating = true
        val prompt = BiometricPrompt(
            this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    authenticating = false
                    unlocked = true
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    authenticating = false
                }
            }
        )
        prompt.authenticate(
            BiometricPrompt.PromptInfo.Builder()
                .setTitle("Unlock Battery Tracker")
                .setAllowedAuthenticators(AUTH)
                .build()
        )
    }

    private fun setLock(on: Boolean): Boolean {
        if (on && BiometricManager.from(this).canAuthenticate(AUTH) != BiometricManager.BIOMETRIC_SUCCESS) {
            Toast.makeText(this, "Set a screen lock (PIN, pattern, or fingerprint) in phone settings first.", Toast.LENGTH_LONG).show()
            return false
        }
        settings.lockOn = on
        settings.save()
        unlocked = true
        return true
    }

    private fun setSecure(on: Boolean) {
        settings.secureOn = on
        settings.save()
        applySecure(on)
    }

    private fun applySecure(on: Boolean) {
        if (on) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    private fun startTracking() =
        ContextCompat.startForegroundService(this, Intent(this, BatteryService::class.java))
}

@Composable
fun AppTheme(dark: Boolean, content: @Composable () -> Unit) {
    val scheme = if (dark) darkColorScheme(primary = Green) else lightColorScheme(primary = Green)
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun AppScreen(settings: AppSettings, onLock: (Boolean) -> Boolean, onSecure: (Boolean) -> Unit) {
    var tab by rememberSaveable { mutableStateOf(0) }
    val tabs = listOf("🏠" to "Home", "📋" to "History", "📊" to "Insights", "ℹ️" to "Details", "⚙️" to "Settings")
    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Text(t.first) },
                        label = { Text(t.second) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            Crossfade(targetState = tab, label = "tab") { t ->
                when (t) {
                    0 -> HomeScreen(settings)
                    1 -> HistoryScreen(settings)
                    2 -> InsightsScreen(settings)
                    3 -> DetailsScreen(settings)
                    else -> SettingsScreen(settings, onLock, onSecure)
                }
            }
        }
    }
}

@Composable
fun LockScreen(onUnlock: () -> Unit) {
    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("🔒", style = MaterialTheme.typography.displayMedium)
        Spacer(Modifier.height(12.dp))
        Text("Battery Tracker is locked", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        Button(onClick = onUnlock) { Text("Unlock") }
    }
}
