package com.example.batterytracker

import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.view.WindowManager
import android.widget.Toast
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.fragment.app.FragmentActivity
import android.os.Build
import android.os.Bundle
import android.text.format.DateUtils
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

val Green = Color(0xFF2E9E5B)
val Orange = Color(0xFFF29D38)

private val AUTH = BiometricManager.Authenticators.BIOMETRIC_WEAK or
    BiometricManager.Authenticators.DEVICE_CREDENTIAL

class MainActivity : FragmentActivity() {
    private lateinit var prefs: SharedPreferences
    private var unlocked by mutableStateOf(false)
    private var lockOn by mutableStateOf(false)
    private var authenticating = false

    private val permission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { startTracking() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        prefs = getSharedPreferences("settings", MODE_PRIVATE)
        lockOn = prefs.getBoolean("lock", false)
        val secureOn = prefs.getBoolean("secure", true)
        applySecure(secureOn)

        if (Build.VERSION.SDK_INT >= 33) permission.launch(Manifest.permission.POST_NOTIFICATIONS)
        else startTracking()

        setContent {
            AppTheme {
                Surface(Modifier.fillMaxSize()) {
                    if (!lockOn || unlocked) {
                        AppScreen(lockOn, secureOn, ::setLock, ::setSecure)
                    } else {
                        LockScreen { authenticate() }
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (lockOn && !unlocked) authenticate()
    }

    override fun onStop() {
        super.onStop()
        if (lockOn && !authenticating) unlocked = false
    }

    private fun authenticate() {
        if (authenticating) return
        if (BiometricManager.from(this).canAuthenticate(AUTH) != BiometricManager.BIOMETRIC_SUCCESS) {
            unlocked = true
            return
        }
        authenticating = true
        val prompt = BiometricPrompt(
            this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    authenticating = false
                    unlocked = true
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    authenticating = false
                }
            }
        )
        prompt.authenticate(
            BiometricPrompt.PromptInfo.Builder()
                .setTitle("Unlock Battery Tracker")
                .setAllowedAuthenticators(AUTH)
                .build()
        )
    }

    private fun setLock(on: Boolean): Boolean {
        if (on && BiometricManager.from(this).canAuthenticate(AUTH) != BiometricManager.BIOMETRIC_SUCCESS) {
            Toast.makeText(this, "Set a screen lock (PIN, pattern, or fingerprint) in phone settings first.", Toast.LENGTH_LONG).show()
            return false
        }
        prefs.edit().putBoolean("lock", on).apply()
        lockOn = on
        unlocked = true
        return true
    }

    private fun setSecure(on: Boolean) {
        prefs.edit().putBoolean("secure", on).apply()
        applySecure(on)
    }

    private fun applySecure(on: Boolean) {
        if (on) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    private fun startTracking() =
        ContextCompat.startForegroundService(this, Intent(this, BatteryService::class.java))
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) darkColorScheme(primary = Green)
    else lightColorScheme(primary = Green)
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun HomeScreen() {
    val ctx = LocalContext.current
    val flow = remember { AppDb.get(ctx).dao().all() }
    val sessions by flow.collectAsState(initial = emptyList())
    var filter by remember { mutableIntStateOf(0) }

    val live = sessions.firstOrNull { it.open }
    val done = sessions.filter { !it.open }
    val shown = when (filter) {
        1 -> sessions.filter { it.charging }
        2 -> sessions.filter { !it.charging }
        else -> sessions
    }
    val groups = remember(shown) { shown.groupBy { dayLabel(it.startTime) } }

    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Battery Tracker", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }
        item { LiveCard(live) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatBox("%.1f %%/h".format(avgRate(done.filter { it.charging })), "Avg charge", Green, Modifier.weight(1f))
                StatBox("%.1f %%/h".format(avgRate(done.filter { !it.charging })), "Avg drain", Orange, Modifier.weight(1f))
                StatBox("${done.size}", "Sessions", MaterialTheme.colorScheme.onSurface, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("All", "Charging", "On battery").forEachIndexed { i, label ->
                    FilterChip(selected = filter == i, onClick = { filter = i }, label = { Text(label) })
                }
            }
        }
        if (shown.isEmpty()) {
            item { Text("No sessions yet. Plug in or unplug your phone and wait a couple of minutes.") }
        }
        for ((day, list) in groups) {
            item(key = "h$day") {
                Text(day, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(list, key = { it.id }) { SessionCard(it) }
        }
    }
}

@Composable
fun BatteryRing(pct: Int, color: Color) {
    val track = MaterialTheme.colorScheme.surfaceVariant
    Box(Modifier.size(110.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
            val inset = 6.dp.toPx()
            val sz = Size(size.width - inset * 2, size.height - inset * 2)
            drawArc(track, -90f, 360f, false, Offset(inset, inset), sz, style = stroke)
            drawArc(color, -90f, 360f * pct / 100f, false, Offset(inset, inset), sz, style = stroke)
        }
        Text("$pct%", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun LiveCard(s: Session?) {
    val color = if (s?.charging == true) Green else Orange
    val timeFmt = SimpleDateFormat("h:mm a", Locale.getDefault())
    Card(Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            BatteryRing(s?.endPct ?: 0, color)
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    when {
                        s == null -> "Waiting for data…"
                        s.charging -> "⚡ Charging (${s.source})"
                        else -> "🔋 On battery"
                    },
                    style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = color
                )
                if (s != null) {
                    Text("Since ${timeFmt.format(Date(s.startTime))} · ${formatDuration(s.endTime - s.startTime)}")
                    Text(
                        "Started at ${s.startPct}% · ${"%.1f".format(s.maxTempC)} °C max",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun StatBox(value: String, label: String, color: Color, modifier: Modifier) {
    Card(modifier) {
        Column(Modifier.padding(12.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = color)
            Text(label, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
fun SessionCard(s: Session) {
    val accent = if (s.charging) Green else Orange
    val dur = s.endTime - s.startTime
    val delta = s.endPct - s.startPct
    val rate = rateOf(s)
    val fmt = SimpleDateFormat("h:mm a", Locale.getDefault())

    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.height(IntrinsicSize.Min)) {
            Box(Modifier.width(6.dp).fillMaxHeight().background(accent))
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (s.charging) "Charging · ${s.source}" else "On battery",
                            fontWeight = FontWeight.Bold, color = accent
                        )
                        Text(
                            "${fmt.format(Date(s.startTime))} → ${if (s.open) "now" else fmt.format(Date(s.endTime))}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        "${if (delta >= 0) "+" else ""}$delta%",
                        style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold
                    )
                }
                LinearProgressIndicator(
                    progress = { s.endPct / 100f },
                    modifier = Modifier.fillMaxWidth(),
                    color = accent
                )
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("${s.startPct}% → ${s.endPct}%", style = MaterialTheme.typography.bodySmall)
                    Text("⏱ ${formatDuration(dur)}", style = MaterialTheme.typography.bodySmall)
                    Text("${"%.1f".format(rate)} %/h", style = MaterialTheme.typography.bodySmall)
                    Text("${"%.0f".format(s.maxTempC)}°C", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

fun rateOf(s: Session): Double {
    val h = (s.endTime - s.startTime) / 3_600_000.0
    return if (h > 0) abs((s.endPct - s.startPct) / h) else 0.0
}

fun avgRate(l: List<Session>): Double {
    val r = l.filter { it.endTime > it.startTime }.map { rateOf(it) }
    return if (r.isEmpty()) 0.0 else r.average()
}

fun dayLabel(ms: Long): String = when {
    DateUtils.isToday(ms) -> "Today"
    DateUtils.isToday(ms + 86_400_000L) -> "Yesterday"
    else -> SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date(ms))
}

fun formatDuration(ms: Long): String {
    val m = ms / 60_000
    return if (m >= 60) "${m / 60}h ${m % 60}m" else "${m}m"
}

@Composable
fun AppScreen(lockOn: Boolean, secureOn: Boolean, onLock: (Boolean) -> Boolean, onSecure: (Boolean) -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Text("🏠") }, label = { Text("Home") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Text("📋") }, label = { Text("History") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Text("⚙️") }, label = { Text("Settings") })
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> HomeScreen()
                1 -> ChargingHistoryScreen()
                else -> SettingsScreen(lockOn, secureOn, onLock, onSecure)
            }
        }
    }
}

@Composable
fun LockScreen(onUnlock: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("🔒", style = MaterialTheme.typography.displayMedium)
        Spacer(Modifier.height(12.dp))
        Text("Battery Tracker is locked", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        Button(onClick = onUnlock) { Text("Unlock") }
    }
}

@Composable
fun SettingsScreen(lockOn: Boolean, secureOn: Boolean, onLock: (Boolean) -> Boolean, onSecure: (Boolean) -> Unit) {
    var lock by remember { mutableStateOf(lockOn) }
    var secure by remember { mutableStateOf(secureOn) }
    val ctx = LocalContext.current
    val version = remember { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }
    Column(
        Modifier.fillMaxSize().statusBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        SettingRow("App lock", "Ask for fingerprint, face, or phone PIN when opening the app.", lock) {
            lock = onLock(it) && it
        }
        SettingRow("Hide screen in recent apps", "Blocks screenshots and blanks the app preview.", secure) {
            secure = it
            onSecure(it)
        }
        Text(
            "All your battery data stays on this phone. The app has no internet access.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text("Version $version", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun SettingRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun ChargingHistoryScreen() {
    val ctx = LocalContext.current
    val flow = remember { AppDb.get(ctx).dao().all() }
    val all by flow.collectAsState(initial = emptyList())
    val charges = all.filter { it.charging }
    val totalMs = charges.sumOf { it.endTime - it.startTime }
    val totalPct = charges.sumOf { (it.endPct - it.startPct).coerceAtLeast(0) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Charging history", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatBox("${charges.size}", "Charges", Green, Modifier.weight(1f))
                StatBox(formatDuration(totalMs), "Total time", Green, Modifier.weight(1f))
                StatBox("+$totalPct%", "Total charged", Green, Modifier.weight(1f))
            }
        }
        if (charges.isEmpty()) {
            item { Text("No charging sessions yet. Plug in your charger for a couple of minutes.") }
        }
        items(charges, key = { it.id }) { ChargeRow(it) }
    }
}

@Composable
fun ChargeRow(s: Session) {
    val dateFmt = SimpleDateFormat("EEE, d MMM yyyy", Locale.getDefault())
    val timeFmt = SimpleDateFormat("h:mm a", Locale.getDefault())
    val dayKey = SimpleDateFormat("yyyyMMdd", Locale.getDefault())
    val nextDay = dayKey.format(Date(s.startTime)) != dayKey.format(Date(s.endTime))
    val gained = (s.endPct - s.startPct).coerceAtLeast(0)

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(dateFmt.format(Date(s.startTime)), fontWeight = FontWeight.Bold)
                    if (s.open) Text("In progress", color = Green, style = MaterialTheme.typography.bodySmall)
                }
                Text("+$gained%", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Green)
            }
            Text(
                "Plugged in ${timeFmt.format(Date(s.startTime))}  →  " +
                    (if (s.open) "now" else timeFmt.format(Date(s.endTime)) + if (nextDay) " (next day)" else "")
            )
            Text("Charged for ${formatDuration(s.endTime - s.startTime)}")
            Text(
                "${s.startPct}% → ${s.endPct}% · ${s.source}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
