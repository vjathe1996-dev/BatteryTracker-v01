package com.example.batterytracker

import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

@Composable
fun InsightsScreen(settings: AppSettings, scroll: ScrollState) {
    val ctx = LocalContext.current
    val dao = remember { AppDb.get(ctx).dao() }
    val flow = remember { dao.all() }
    val sampleFlow = remember { dao.chargeSamples() }
    val sessions by flow.collectAsState(initial = emptyList())
    val chargeSamples by sampleFlow.collectAsState(initial = emptyList())
    var range by rememberSaveable { mutableStateOf(0) }
    val days = if (range == 0) 7 else 30
    val today = remember { LocalDate.now() }
    val dates = remember(days) { (days - 1 downTo 0).map { today.minusDays(it.toLong()) } }
    val zone = ZoneId.systemDefault()
    fun dateOf(ms: Long): LocalDate = Instant.ofEpochMilli(ms).atZone(zone).toLocalDate()

    val labels = dates.map { it.format(DateTimeFormatter.ofPattern("d MMM")) }
    val charged = dates.map { d ->
        sessions.filter { it.charging && dateOf(it.startTime) == d }.sumOf { it.gain.coerceAtLeast(0) }.toFloat()
    }
    val drained = dates.map { d ->
        sessions.filter { !it.charging && dateOf(it.startTime) == d }.sumOf { (-it.gain).coerceAtLeast(0) }.toFloat()
    }
    val inRange = sessions.filter { !it.open && !dateOf(it.startTime).isBefore(dates.first()) }
    val charges = inRange.filter { it.charging }
    val avgFull = if (charges.isEmpty()) 0L else charges.sumOf { it.fullMs } / charges.size
    val avgStart = if (charges.isEmpty()) 0 else charges.sumOf { it.startPct } / charges.size
    val bySource = charges.groupBy { it.source }.map { (k, v) -> k to avgRate(v) }.filter { it.second > 0 }
    val caps = sessions.filter { it.charging }.sortedBy { it.startTime }.mapNotNull { it.capacityMah() }
    val rates = remember(chargeSamples) { bandRates(chargeSamples) }
    val bands = BAND_LABELS.zip(rates).mapNotNull { (l, r) -> r?.let { l to it } }

    val tips = buildList {
        if (charges.isNotEmpty() && avgFull > 30 * 60_000L) {
            add("💡 Your phone sits full or held for about ${formatDuration(avgFull)} per charge. A charge limit of 80–90% can reduce battery wear.")
        }
        if (charges.isNotEmpty() && charges.count { it.startPct <= 15 } * 2 >= charges.size) {
            add("💡 You often start charging below 15%. Charging earlier is gentler on the battery.")
        }
        if (charges.any { it.maxTempC >= 40f }) {
            add("🔥 Some charges reached 40°C or more. Avoid charging under a pillow or in direct sun.")
        }
        val long = charges.count { it.durationMs > 6 * 3_600_000L }
        if (long > 0) add("🌙 $long charge(s) lasted over 6 hours, likely overnight. A smart charger or limit alert can help.")
        if (isEmpty()) add("Keep using the app. Tips appear after a few charges.")
    }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(scroll).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Insights", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        FilterRow(listOf("Last 7 days", "Last 30 days"), range) { range = it }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatBox("%.1f %%/h".format(avgRate(charges)), "Avg charge speed", Green, Modifier.weight(1f))
            StatBox(formatDuration(avgFull), "Avg time full or held", Orange, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatBox("$avgStart%", "Avg start level", MaterialTheme.colorScheme.onSurface, Modifier.weight(1f))
            StatBox("${charges.size}", "Charges", MaterialTheme.colorScheme.onSurface, Modifier.weight(1f))
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Charged per day (%)", fontWeight = FontWeight.Bold)
                BarChart(labels, charged, Green, "%")
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Drained per day (%)", fontWeight = FontWeight.Bold)
                BarChart(labels, drained, Orange, "%")
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Charging speed by level", fontWeight = FontWeight.Bold)
                if (bands.isEmpty()) {
                    Text("Needs a few completed charges.", style = MaterialTheme.typography.bodySmall)
                } else {
                    HBars(bands, Green, "%/h")
                    Text(
                        "Charging usually slows down as the battery fills up.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Charger comparison", fontWeight = FontWeight.Bold)
                if (bySource.isEmpty()) {
                    Text("Charge a few times to compare chargers.", style = MaterialTheme.typography.bodySmall)
                } else {
                    HBars(bySource, Green, "%/h")
                    if (bySource.size < 2) {
                        Text(
                            "Try another charger type (AC, USB, wireless) to compare.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Battery health estimate", fontWeight = FontWeight.Bold)
                if (caps.isEmpty()) {
                    Text(
                        "Needs a charge of 20% or more on a phone that reports charge data.",
                        style = MaterialTheme.typography.bodySmall
                    )
                } else {
                    val est = caps.takeLast(3).average()
                    Text("About ${est.roundToInt()} mAh full capacity", style = MaterialTheme.typography.titleMedium, color = Green)
                    if (settings.designMah > 0) {
                        val pct = (est / settings.designMah * 100).coerceAtMost(100.0).roundToInt()
                        Text("$pct% of the original ${settings.designMah} mAh")
                    } else {
                        Text(
                            "Add your phone's original capacity in Settings to see a health %.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    if (caps.size >= 2) LineChart(caps.map { it.toFloat() }, Green)
                    Text(
                        "Estimates vary by phone and improve with more charges.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Text("Tips", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        tips.forEach { Card(Modifier.fillMaxWidth()) { Text(it, Modifier.padding(16.dp)) } }
        Spacer(Modifier.height(8.dp))
    }
}
