package com.example.batterytracker

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.math.max

class BatteryService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            scope.launch { handle(i) }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val ch = NotificationChannel("tracker", "Battery tracking", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        val n = NotificationCompat.Builder(this, "tracker")
            .setContentTitle("Battery Tracker is running")
            .setContentText("Recording charge and drain sessions")
            .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(
            this, 1, n,
            if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        )
        registerReceiver(receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        unregisterReceiver(receiver)
        scope.cancel()
        super.onDestroy()
    }

    private suspend fun handle(i: Intent) {
        mutex.withLock {
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            if (level < 0 || scale <= 0) return@withLock
            val pct = level * 100 / scale
            val plug = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
            val charging = plug != 0
            val temp = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
            val source = when (plug) {
                BatteryManager.BATTERY_PLUGGED_AC -> "AC"
                BatteryManager.BATTERY_PLUGGED_USB -> "USB"
                BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
                else -> "Battery"
            }
            val now = System.currentTimeMillis()
            val dao = AppDb.get(this).dao()
            val cur = dao.openSession()

            if (cur != null && cur.charging == charging) {
                // same session: keep updating the "last seen" values
                dao.update(cur.copy(endTime = now, endPct = pct, maxTempC = max(cur.maxTempC, temp)))
                return@withLock
            }
            if (cur != null) {
                // plug state changed: close old session (ignore very short ones)
                if (cur.endTime - cur.startTime < 120_000) dao.delete(cur)
                else dao.update(cur.copy(open = false))
            }
            dao.insert(
                Session(
                    charging = charging, startTime = now, endTime = now,
                    startPct = pct, endPct = pct, source = source, maxTempC = temp
                )
            )
        }
    }
}
