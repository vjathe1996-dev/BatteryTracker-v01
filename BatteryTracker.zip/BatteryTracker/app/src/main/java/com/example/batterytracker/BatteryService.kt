package com.example.batterytracker

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.*

class BatteryService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var nm: NotificationManager
    private var lastPct = -2
    private var lastCharging = false

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            scope.launch { handle(i, null) }
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val on = i.action == Intent.ACTION_SCREEN_ON
            val sticky = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
            scope.launch { handle(sticky, on) }
        }
    }

    override fun onCreate() {
        super.onCreate()
        running = true
        nm = getSystemService(NotificationManager::class.java)
        Tracker.screenOn = (getSystemService(POWER_SERVICE) as PowerManager).isInteractive
        Tracker.ensureChannels(this)
        ServiceCompat.startForeground(
            this, 1, ongoing(-1, false),
            if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        )
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        registerReceiver(screenReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        running = false
        unregisterReceiver(batteryReceiver)
        unregisterReceiver(screenReceiver)
        scope.cancel()
        super.onDestroy()
    }

    private suspend fun handle(i: Intent, newScreen: Boolean?) {
        val r = Tracker.handle(applicationContext, i, newScreen) ?: return
        if (r.pct != lastPct || r.charging != lastCharging) {
            lastPct = r.pct
            lastCharging = r.charging
            nm.notify(1, ongoing(r.pct, r.charging))
        }
    }

    private fun ongoing(pct: Int, charging: Boolean): Notification {
        val text = if (pct < 0) "Recording charge and drain sessions"
        else "$pct% · ${if (charging) "Charging" else "On battery"}"
        val pi = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, "tracker")
            .setContentTitle("Battery Tracker is running")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .setContentIntent(pi)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .build()
    }

    companion object {
        @Volatile var running = false
    }
}
