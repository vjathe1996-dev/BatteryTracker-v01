package com.example.batterytracker

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.math.max

class BatteryService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()
    private lateinit var sp: SharedPreferences
    private lateinit var nm: NotificationManager
    private lateinit var bm: BatteryManager
    private var screenOn = true
    private var firstEvent = true
    private var limitAlerted = false
    private var lowAlerted = false
    private var heatAlerted = false

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            scope.launch { handle(i, null) }
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val on = i.action == Intent.ACTION_SCREEN_ON
            val sticky = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
            scope.launch { handle(sticky, on) }
        }
    }

    override fun onCreate() {
        super.onCreate()
        sp = getSharedPreferences("settings", MODE_PRIVATE)
        nm = getSystemService(NotificationManager::class.java)
        bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        screenOn = (getSystemService(POWER_SERVICE) as PowerManager).isInteractive
        nm.createNotificationChannel(NotificationChannel("tracker", "Battery tracking", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("alerts", "Battery alerts", NotificationManager.IMPORTANCE_HIGH))
        ServiceCompat.startForeground(
            this, 1, ongoing(-1, false),
            if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        )
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        registerReceiver(screenReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        unregisterReceiver(batteryReceiver)
        unregisterReceiver(screenReceiver)
        scope.cancel()
        super.onDestroy()
    }

    private fun openAppIntent(code: Int) =
        PendingIntent.getActivity(this, code, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)

    private fun ongoing(pct: Int, charging: Boolean): Notification {
        val text = if (pct < 0) "Recording charge and drain sessions"
        else "$pct% · ${if (charging) "Charging" else "On battery"}"
        return NotificationCompat.Builder(this, "tracker")
            .setContentTitle("Battery Tracker is running")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .setContentIntent(openAppIntent(1))
            .setOngoing(true)
            .build()
    }

    private fun alert(id: Int, title: String, text: String) {
        nm.notify(
            id,
            NotificationCompat.Builder(this, "alerts")
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(openAppIntent(id))
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build()
        )
    }

    private suspend fun handle(i: Intent, newScreen: Boolean?) {
        mutex.withLock {
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            if (level < 0 || scale <= 0) return@withLock
            val pct = level * 100 / scale
            val plug = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
            val charging = plug != 0
            val temp = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
            val source = when (plug) {
                BatteryManager.BATTERY_PLUGGED_AC -> "AC"
                BatteryManager.BATTERY_PLUGGED_USB -> "USB"
                BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
                else -> "Battery"
            }
            val raw = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
            val counter = if (raw > 0 && raw != Long.MIN_VALUE) raw else 0L
            val now = System.currentTimeMillis()
            val dao = AppDb.get(this).dao()
            val cur = dao.openSession()

            if (cur != null && cur.charging == charging) {
                var u = cur.copy(
                    endTime = now, endPct = pct,
                    maxTempC = max(cur.maxTempC, temp),
                    endCounterUah = if (counter > 0) counter else cur.endCounterUah
                )
                if (!firstEvent) {
                    val el = now - cur.endTime
                    val dp = pct - cur.endPct
                    u = if (screenOn) u.copy(screenOnMs = u.screenOnMs + el, screenOnPct = u.screenOnPct + dp)
                    else u.copy(screenOffMs = u.screenOffMs + el, screenOffPct = u.screenOffPct + dp)
                    if (charging && cur.endPct >= 100) u = u.copy(fullMs = u.fullMs + el)
                }
                dao.update(u)
            } else {
                if (cur != null) {
                    if (cur.endTime - cur.startTime < 120_000) dao.delete(cur)
                    else dao.update(cur.copy(open = false))
                }
                dao.insert(
                    Session(
                        charging = charging, startTime = now, endTime = now,
                        startPct = pct, endPct = pct, source = source, maxTempC = temp,
                        startCounterUah = counter, endCounterUah = counter
                    )
                )
            }
            if (newScreen != null) screenOn = newScreen
            firstEvent = false
            nm.notify(1, ongoing(pct, charging))
            checkAlerts(pct, charging, temp)
        }
    }

    private fun checkAlerts(pct: Int, charging: Boolean, temp: Float) {
        if (sp.getBoolean("limitOn", true)) {
            val lim = sp.getInt("limitPct", 100)
            if (charging && pct >= lim) {
                if (!limitAlerted) {
                    limitAlerted = true
                    alert(2, "Charge limit reached", "Battery is at $pct%. You can unplug the charger.")
                }
            } else if (!charging) limitAlerted = false
        }
        if (sp.getBoolean("lowOn", true)) {
            val low = sp.getInt("lowPct", 15)
            if (!charging && pct <= low) {
                if (!lowAlerted) {
                    lowAlerted = true
                    alert(3, "Battery low", "Battery is at $pct%. Plug in your charger soon.")
                }
            } else if (charging || pct > low + 3) lowAlerted = false
        }
        if (sp.getBoolean("heatOn", true)) {
            val heat = sp.getInt("heatC", 40)
            if (temp >= heat) {
                if (!heatAlerted) {
                    heatAlerted = true
                    alert(4, "Battery is hot", "Temperature is ${"%.0f".format(temp)}°C. Let your phone cool down.")
                }
            } else if (temp < heat - 3) heatAlerted = false
        }
    }
}
