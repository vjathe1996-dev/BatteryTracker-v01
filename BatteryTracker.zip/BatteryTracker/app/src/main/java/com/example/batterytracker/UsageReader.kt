package com.example.batterytracker

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import java.util.Calendar

data class AppUse(
    val pkg: String,
    val label: String,
    val fgMs: Long,
    val estPct: Double,
    val launches: Int,
    val lastUsed: Long
)

data class AppUsageResult(val apps: List<AppUse>, val totalDrainPct: Int, val backgroundPct: Double)

fun hasUsageAccess(ctx: Context): Boolean = try {
    val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    val mode = if (Build.VERSION.SDK_INT >= 29) {
        ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
    } else {
        ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
    }
    mode == AppOpsManager.MODE_ALLOWED
} catch (e: Exception) {
    false
}

fun startOfToday(): Long {
    val c = Calendar.getInstance()
    c.set(Calendar.HOUR_OF_DAY, 0)
    c.set(Calendar.MINUTE, 0)
    c.set(Calendar.SECOND, 0)
    c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

private fun labelOf(pm: PackageManager, pkg: String): String = try {
    pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
} catch (e: Exception) {
    if (pkg == "com.android.systemui") "System UI"
    else pkg.substringAfterLast('.').replaceFirstChar { it.uppercase() }
}

private fun readForeground(
    ctx: Context, from: Long, to: Long
): Pair<Map<String, List<Pair<Long, Long>>>, Map<String, Int>> {
    val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
    val events = usm.queryEvents(from, to)
    val e = UsageEvents.Event()
    val openAt = HashMap<String, Long>()
    val lastEnd = HashMap<String, Long>()
    val out = HashMap<String, MutableList<Pair<Long, Long>>>()
    val launches = HashMap<String, Int>()
    while (events.hasNextEvent()) {
        events.getNextEvent(e)
        val pkg = e.packageName ?: continue
        when (e.eventType) {
            UsageEvents.Event.ACTIVITY_RESUMED -> {
                if (!openAt.containsKey(pkg)) {
                    openAt[pkg] = e.timeStamp
                    if (e.timeStamp - (lastEnd[pkg] ?: 0L) > 2_000L) launches[pkg] = (launches[pkg] ?: 0) + 1
                }
            }
            UsageEvents.Event.ACTIVITY_PAUSED, UsageEvents.Event.ACTIVITY_STOPPED -> {
                val s = openAt.remove(pkg)
                if (s != null && e.timeStamp > s) {
                    out.getOrPut(pkg) { mutableListOf() }.add(s to e.timeStamp)
                    lastEnd[pkg] = e.timeStamp
                }
            }
        }
    }
    for ((pkg, s) in openAt) {
        if (to > s) out.getOrPut(pkg) { mutableListOf() }.add(s to to)
    }
    return out to launches
}

suspend fun loadAppUsage(ctx: Context, from: Long, to: Long): AppUsageResult {
    val app = ctx.applicationContext
    val dao = AppDb.get(app).dao()
    val (intervals, launches) = readForeground(app, from, to)
    val samples = dao.dischargeSamplesSince(from).filter { it.time <= to }
    val weight = bgWeight(dao.snapshot().filter { !it.charging })
    val (share, bg) = attributeDrain(samples, intervals, weight)
    val pm = app.packageManager
    val apps = intervals.map { (pkg, ivs) ->
        AppUse(
            pkg = pkg,
            label = labelOf(pm, pkg),
            fgMs = ivs.sumOf { it.second - it.first },
            estPct = share[pkg] ?: 0.0,
            launches = launches[pkg] ?: 0,
            lastUsed = ivs.maxOf { it.second }
        )
    }.filter { it.fgMs >= 5_000L }
        .sortedWith(compareByDescending<AppUse> { it.estPct }.thenByDescending { it.fgMs })
    val total = samples.groupBy { it.sessionId }.values.sumOf { l ->
        l.sortedBy { it.time }.zipWithNext { a, b -> maxOf(0, a.pct - b.pct) }.sum()
    }
    return AppUsageResult(apps, total, bg)
}
