package com.example.batterytracker

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

@Composable
fun DetailsScreen(settings: AppSettings, scroll: ScrollState) {
    val ctx = LocalContext.current
    val flow = remember { AppDb.get(ctx).dao().all() }
    val sessions by flow.collectAsState(initial = emptyList())
    val info by produceState(emptyList<InfoSection>(), settings.useF) {
        while (true) {
            value = withContext(Dispatchers.Default) { readInfo(ctx, settings.useF) }
            delay(2000)
        }
    }

    val fmt = SimpleDateFormat("EEE, d MMM yyyy · h:mm a", Locale.getDefault())
    val charges = sessions.filter { it.charging && !it.open }
    val totalMs = charges.sumOf { it.durationMs }
    val totalPct = charges.sumOf { it.gain.coerceAtLeast(0) }
    val caps = sessions.filter { it.charging }.sortedBy { it.startTime }.mapNotNull { it.capacityMah() }
    val est = caps.takeLast(3).takeIf { it.isNotEmpty() }?.average()
    val lastFull = sessions.filter { it.charging && it.endPct >= 100 }.maxOfOrNull { it.endTime }

    val appStats = listOf(
        "Tracking since" to (sessions.minOfOrNull { it.startTime }?.let { fmt.format(Date(it)) } ?: "n/a"),
        "Sessions recorded" to "${sessions.size}",
        "Charges recorded" to "${charges.size}",
        "Total time charging" to formatDuration(totalMs),
        "Total charged" to "$totalPct%",
        "Full cycles (tracked)" to "%.1f".format(totalPct / 100.0),
        "Last charged to 100%" to (lastFull?.let { fmt.format(Date(it)) } ?: "Not yet"),
        "Longest charge" to (charges.maxOfOrNull { it.durationMs }?.let { formatDuration(it) } ?: "n/a"),
        "Average charge speed" to "%.1f %%/h".format(avgRate(charges)),
        "Average drain speed" to "%.1f %%/h".format(avgRate(sessions.filter { !it.charging && !it.open })),
        "Estimated capacity" to (est?.let { "${it.roundToInt()} mAh" } ?: "Needs a 20%+ charge"),
        "Original capacity" to if (settings.designMah > 0) "${settings.designMah} mAh" else "Not set",
        "Health (estimate)" to if (est != null && settings.designMah > 0)
            "${(est / settings.designMah * 100).coerceAtMost(100.0).roundToInt()}%" else "n/a"
    )

    val report = remember(info, appStats) {
        (info + listOf("Recorded by Battery Tracker" to appStats)).joinToString("\n\n") { (title, rows) ->
            title + "\n" + rows.joinToString("\n") { "${it.first}: ${it.second}" }
        }
    }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(scroll).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Battery details", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(
            "Live values refresh every 2 seconds. Anything your phone doesn't report shows n/a.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        info.forEach { (title, rows) ->
            Section(title) { rows.forEach { InfoRow(it.first, it.second) } }
        }
        AppUsageSection()
        Section("Recorded by Battery Tracker") { appStats.forEach { InfoRow(it.first, it.second) } }

        Section("Shortcuts") {
            Button(
                onClick = { openSafely(ctx, Intent(Intent.ACTION_POWER_USAGE_SUMMARY)) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Open Android battery usage") }
            OutlinedButton(
                onClick = { openSafely(ctx, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Battery optimization settings") }
            OutlinedButton(
                onClick = {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, report)
                    }
                    openSafely(ctx, Intent.createChooser(send, "Share battery report"))
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Share battery report") }
            Text(
                "Set Background use to Unrestricted so Android doesn't stop the tracker.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.Top) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f).padding(end = 8.dp))
        Text(value, fontWeight = FontWeight.Medium, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
    }
}
