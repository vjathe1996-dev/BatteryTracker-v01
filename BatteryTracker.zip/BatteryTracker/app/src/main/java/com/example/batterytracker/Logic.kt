package com.example.batterytracker

val BAND_LABELS = listOf("0–50%", "50–80%", "80–100%")

fun bandOf(p: Int): Int = if (p < 50) 0 else if (p < 80) 1 else 2

fun bandRates(samples: List<Sample>): List<Double?> {
    val dp = DoubleArray(3)
    val dh = DoubleArray(3)
    samples.groupBy { it.sessionId }.values.forEach { list ->
        val s = list.sortedBy { it.time }
        for (k in 1 until s.size) {
            val a = s[k - 1]
            val b = s[k]
            val d = b.pct - a.pct
            val h = (b.time - a.time) / 3_600_000.0
            if (d > 0 && h > 0) {
                val band = bandOf(a.pct)
                dp[band] += d.toDouble()
                dh[band] += h
            }
        }
    }
    return (0..2).map { if (dh[it] > 0.01) dp[it] / dh[it] else null }
}

fun etaToFullHours(pct: Int, rates: List<Double?>, fallback: Double): Double? {
    if (pct >= 100) return 0.0
    val known = rates.filterNotNull()
    val avg = if (known.isNotEmpty()) known.average() else fallback
    if (avg <= 0.0) return null
    var hours = 0.0
    var p = pct
    while (p < 100) {
        val band = bandOf(p)
        val end = when (band) {
            0 -> 50
            1 -> 80
            else -> 100
        }
        val rate = (rates[band] ?: avg).coerceAtLeast(1.0)
        hours += (end - p) / rate
        p = end
    }
    return hours
}

fun bgWeight(sessions: List<Session>): Double {
    val onMs = sessions.sumOf { it.screenOnMs }
    val offMs = sessions.sumOf { it.screenOffMs }
    val onPct = sessions.sumOf { kotlin.math.abs(it.screenOnPct) }
    val offPct = sessions.sumOf { kotlin.math.abs(it.screenOffPct) }
    if (onMs < 600_000L || offMs < 600_000L || onPct <= 0) return 0.1
    val ratio = (offPct.toDouble() / offMs) / (onPct.toDouble() / onMs)
    return ratio.coerceIn(0.02, 0.5)
}

fun attributeDrain(
    samples: List<Sample>,
    intervals: Map<String, List<Pair<Long, Long>>>,
    bgWeight: Double
): Pair<Map<String, Double>, Double> {
    val share = HashMap<String, Double>()
    var bg = 0.0
    samples.groupBy { it.sessionId }.values.forEach { list ->
        val s = list.sortedBy { it.time }
        for (k in 1 until s.size) {
            val a = s[k - 1]
            val b = s[k]
            val drop = a.pct - b.pct
            val span = b.time - a.time
            if (drop <= 0 || span <= 0) continue
            val ov = HashMap<String, Long>()
            var total = 0L
            for ((pkg, ivs) in intervals) {
                var o = 0L
                for ((x, y) in ivs) {
                    val lo = maxOf(x, a.time)
                    val hi = minOf(y, b.time)
                    if (hi > lo) o += hi - lo
                }
                if (o > 0) {
                    ov[pkg] = o
                    total += o
                }
            }
            val fg = minOf(total, span).toDouble()
            val weightBg = (span - fg) * bgWeight
            val denom = fg + weightBg
            if (denom <= 0.0) continue
            if (total > 0) {
                for ((pkg, o) in ov) {
                    share[pkg] = (share[pkg] ?: 0.0) + drop * (fg / denom) * (o.toDouble() / total)
                }
            }
            bg += drop * (weightBg / denom)
        }
    }
    return share to bg
}
