package com.example.batterytracker

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class LogicTest {
    private fun session(sp: Int, ep: Int, durationMs: Long, charging: Boolean = true) = Session(
        charging = charging, startTime = 0, endTime = durationMs,
        startPct = sp, endPct = ep, source = "AC", maxTempC = 30f, open = false
    )

    @Test
    fun formatsDurations() {
        assertEquals("45m", formatDuration(45 * 60_000L))
        assertEquals("1h 5m", formatDuration(65 * 60_000L))
    }

    @Test
    fun chargeRateIsPercentPerHour() {
        assertEquals(40.0, session(20, 60, 3_600_000L).rate(), 0.001)
        assertEquals(10.0, session(80, 70, 3_600_000L, charging = false).rate(), 0.001)
    }

    @Test
    fun averageRateIgnoresSessionsWithNoChange() {
        val list = listOf(session(20, 60, 3_600_000L), session(50, 50, 3_600_000L))
        assertEquals(40.0, avgRate(list), 0.001)
    }

    @Test
    fun capacityNeedsEnoughCharge() {
        val ok = session(20, 70, 3_600_000L).copy(startCounterUah = 1_000_000, endCounterUah = 3_000_000)
        assertEquals(4000.0, ok.capacityMah()!!, 0.01)
        val small = session(20, 30, 3_600_000L).copy(startCounterUah = 1_000_000, endCounterUah = 1_400_000)
        assertNull(small.capacityMah())
    }

    @Test
    fun bandRatesShowTaper() {
        val h = 3_600_000L
        val samples = listOf(
            Sample(sessionId = 1, time = 0, pct = 10, tempC = 30f, currentMa = 0),
            Sample(sessionId = 1, time = h, pct = 60, tempC = 30f, currentMa = 0),
            Sample(sessionId = 1, time = 2 * h, pct = 70, tempC = 30f, currentMa = 0)
        )
        val rates = bandRates(samples)
        assertEquals(50.0, rates[0]!!, 0.01)
        assertEquals(10.0, rates[1]!!, 0.01)
        assertNull(rates[2])
    }

    @Test
    fun etaUsesBandsAndFallback() {
        val eta = etaToFullHours(40, listOf(50.0, 10.0, null), 30.0)
        assertNotNull(eta)
        assertEquals(3.8667, eta!!, 0.01)
        assertEquals(0.0, etaToFullHours(100, listOf(null, null, null), 0.0)!!, 0.0)
    }

    @Test
    fun csvHasHeaderAndRows() {
        val csv = toCsv(listOf(session(20, 60, 3_600_000L)))
        val lines = csv.trim().lines()
        assertEquals(2, lines.size)
        assertEquals(12, lines[1].split(',').size)
    }

    @Test
    fun drainIsSharedAcrossAppsAndBackground() {
        val h = 3_600_000L
        val samples = listOf(
            Sample(sessionId = 1, time = 0, pct = 50, tempC = 30f, currentMa = 0),
            Sample(sessionId = 1, time = h, pct = 40, tempC = 30f, currentMa = 0)
        )
        val intervals = mapOf(
            "a" to listOf(0L to 30 * 60_000L),
            "b" to listOf(30 * 60_000L to 40 * 60_000L)
        )
        val (share, bg) = attributeDrain(samples, intervals, 0.1)
        assertEquals(7.14, share["a"]!!, 0.01)
        assertEquals(2.38, share["b"]!!, 0.01)
        assertEquals(10.0, share["a"]!! + share["b"]!! + bg, 0.001)
    }

    @Test
    fun backgroundWeightFallsBackWithoutData() {
        assertEquals(0.1, bgWeight(emptyList()), 0.0)
    }
}
