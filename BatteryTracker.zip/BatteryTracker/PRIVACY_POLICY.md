# Privacy Policy for Battery Tracker

Last updated: 24 November 2026

Battery Tracker records your phone's charging and battery drain sessions so you can review them.

**What the app stores:** battery percentage, start and end times of charging and discharging sessions, charger type (AC, USB, wireless), and battery temperature.

**Where it is stored:** only on your phone, in the app's private storage. The app has no internet permission. It does not send, upload, share, or sell any data. It has no accounts, ads, analytics, or third-party tracking.

**Permissions:** notifications and a foreground service keep the tracker running in the background; the boot permission restarts tracking after the phone restarts. Biometric or screen-lock authentication is used only if you turn on App lock, and is handled by Android. The app never sees your fingerprint or PIN.

**Deleting your data:** uninstalling the app or clearing its storage in Android settings removes all recorded data.

**Contact:** [your email address]
