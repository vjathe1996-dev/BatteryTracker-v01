# Changelog

## v1.0 (pre-release build 2)
Fixes: gaps after reboot no longer counted as charge/drain; short unplug blips merge back into one charge;
docks/other chargers labelled "Other"; app lock grace period; keyboard no longer covers fields;
Home uses Android's own time-to-full / time-left when available.
Accuracy: database writes throttled; level samples recorded (per-session graph, charge taper model);
time held at full also counts adaptive-charging holds; background pulse every 15 min and on app open.
Interface: real icons, scroll position kept per tab, accessibility description on battery ring,
first-run guide, warnings when notifications are off or background use is restricted.
Data: CSV import, auto-delete old history option, database indexes. Unit tests for core maths.
Not yet done: translations (strings still in code), premium/ads, final app ID, release signing key.

## Battery use by app (Details tab)
Optional Usage access; per-app screen time and estimated battery share (matched to battery readings); tap an app for details.
